/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fblin <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/01/08 14:03:37 by fblin             #+#    #+#             */
/*   Updated: 2016/01/23 15:52:14 by fblin            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
 ** RIP David Bowie 08/01/1947 - 10/01/2016
 */
#include "get_next_line.h"

t_reader	*ft_rdrnew(int fd)
{
	t_reader *rdr;

	if (!(rdr = (t_reader *)malloc(sizeof(t_reader))))
		return (0);
	rdr->fd = fd;
	rdr->start = NULL;
	return (rdr);
}

int			ft_bufjoin(t_reader *rdr, char **line)
{
	int		read_ret;
	char	*buf;

	if (rdr->start)
	{
		*line = ft_strdup(rdr->start);
		if (ft_strchr(*line, '\n'))
		{
			rdr->start = ft_strchr(*line, '\n');
			*rdr->start = '\0';
			rdr->start++;
			return (1);
		}
	}
	if (!(buf = ft_strnew(BUFF_SIZE)))
		return (-1);
	while ((read_ret = read(rdr->fd, buf, BUFF_SIZE)) > 0)
	{
		*line = ft_strjoin(*line, buf);
		if (ft_strchr(*line, '\n'))
		{
			rdr->start = ft_strchr(*line, '\n');
			*rdr->start = '\0';
			rdr->start++;
			return (1);
		}
	}
	if (read_ret == 0)
		return (0);
	return (1);
}

t_reader	*ft_getreader(int fd, t_list **rdr_lst)
{
	if (!*rdr_lst)
	{
		*rdr_lst = ft_lstnew(NULL, 0);
	}
	if (!(*rdr_lst)->content)
	{
		(*rdr_lst)->content = ft_rdrnew(fd);
		(*rdr_lst)->next = NULL;
	}
	if (((t_reader *)((*rdr_lst)->content))->fd != fd)
	{
		return (ft_getreader(fd, &((*rdr_lst)->next)));
	}
	return ((t_reader *)((*rdr_lst)->content));
}

int			get_next_line(int const fd, char **line)
{
	static t_list	*rdr_lst = NULL;
	t_reader 		*rdr;

	if (!(rdr = ft_getreader(fd, &rdr_lst)))
		return (-1);
	return (ft_bufjoin(rdr, line));
}
